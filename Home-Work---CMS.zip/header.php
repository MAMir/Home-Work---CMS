<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title><?php bloginfo('name'); wp_title(); ?></title>
<link href="<?php bloginfo('template_url'); ?>\style.css" rel="stylesheet" type="text/css">
</head>

<body>

<div class="container">
  <div class="header"><a href="#"><img src="" alt="" name="" width="" height=""/></a> 
  </div>
