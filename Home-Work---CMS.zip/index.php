<?php
	get_template_part('header');

	get_template_part('loop');

	get_template_part('sidebar', 'right'); // sidebar-right.php

	get_template_part('footer');	
?>

