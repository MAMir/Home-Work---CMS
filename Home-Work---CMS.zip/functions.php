<?php
	add_theme_support('menus');

	register_nav_menu('mainmenu', "Main Manu");

?>