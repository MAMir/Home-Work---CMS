<?php
	get_template_part('header');
	get_template_part('sidebar', 'right');
?>
<article>
	<h1>Peyda nashod....</h1>
	<p>Dobare check kon...</p>
<article>
<?php
	get_template_part('footer');
?>