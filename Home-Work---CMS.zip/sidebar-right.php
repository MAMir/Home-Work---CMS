<div class="sidebar-right">

	<nav>
		<?php
			wp_nav_menu(array(
				'theme_location'  => 'mainmenu',
				'container'       => false, 
				'container_class' => '', 
				'menu_class'      => '', 
				'before'          => '',
				'after'           => '',
				'link_before'     => '',
				'link_after'      => '',
				'items_wrap'      => ''
			));
		?>
	</nav>

</div>